# Clase en vídeo: https://youtu.be/TbcEqkabAWU?t=24010

### Arithmetics ###

def sum_two_values(first_value, second_value):
    return first_value + second_value
